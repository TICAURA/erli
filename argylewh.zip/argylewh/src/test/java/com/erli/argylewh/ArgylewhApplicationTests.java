package com.erli.argylewh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArgylewhApplicationTests {

	@Test
	void contextLoads() {
	}

}
